# 记录格式

## 阅读卡片

用 `library.py card --sha ... --input <json>` 绑定原文版本。最小 JSON 示例：

```json
{
  "title": "以原文为准，不凭文件名补全",
  "bibliography": {"doi": null, "year": null, "verified": false},
  "coverage": "initial",
  "pages_read": [1, 6],
  "question": "研究问题",
  "system_methods": "体系、条件和方法",
  "findings": [{"claim": "发现及适用条件", "pdf_page": 6}],
  "limitations": ["区分作者陈述和助手推断"],
  "relevance": "与当前课题的关系；未知写待判断",
  "unread": ["图表、补充材料、其余正文尚未核查"]
}
```

coverage 为 initial、targeted 或 full，只有真正读完全文才用 full，补充材料另记。pages_read 是实际阅读页。未知字段留空；不复制整篇文章。脚本验证字段和页码不代表验证科学结论。

## 实验分析

按需记录：日期与问题、实验记录位置、确认条件、观察事实、缺失数据、候选解释、支持/反对证据、体系差异、验证实验与对照、现实约束、不同结果的解释、未完成核验。状态用待验证/得到支持/已排除，并记录更新依据。无原始数据不得声称完成统计分析。

## 写作引用

保留“陈述 → 文献身份 → 原文页/图/段 → 支持程度 → 条件与核验状态”。仅已核实书目进入正式参考文献；RIS/BibTeX 未知字段留空。遵循用户目标期刊，不自动仅用 Nature/CNS。
