# 文献接入与低成本缓存

## 本地 PDF

优先使用宿主已有 Python；PDF 提取需 PyMuPDF 或 pypdf，其他操作仅用标准库。若系统 Python 缺解析库，先用 `load_workspace_dependencies` 找 bundled Python；不要默认安装大型依赖。缺依赖时保留 pending/error，明确说明。此脚本不 OCR、不提取图像、不校验 DOI、不运行模型，不代表完成科学阅读。

以下 `PYTHON`、`SKILL`、`PROJECT` 为调用时替换的绝对路径，不是必须创建的环境变量。PowerShell 可用 `& 'python完整路径' 'script完整路径' ...`。

```text
PYTHON SKILL/scripts/library.py --config PROJECT/.xhz-research/config.json init --root 文献目录绝对路径
PYTHON SKILL/scripts/library.py --config PROJECT/.xhz-research/config.json status
PYTHON SKILL/scripts/library.py --config PROJECT/.xhz-research/config.json scan
PYTHON SKILL/scripts/library.py --config PROJECT/.xhz-research/config.json scan --force
PYTHON SKILL/scripts/library.py --config PROJECT/.xhz-research/config.json process --max-files 3
PYTHON SKILL/scripts/library.py --config PROJECT/.xhz-research/config.json search --query "关键词" --limit 5
PYTHON SKILL/scripts/library.py --config PROJECT/.xhz-research/config.json page --sha 内容哈希 --number 1
PYTHON SKILL/scripts/library.py --config PROJECT/.xhz-research/config.json card --sha 内容哈希 --input 阅读卡片JSON路径
```

初始化时 `--root` 可重复；未指定来源时允许初始化空配置，但必须说明没有库可扫描。后续向 config 的 pdf_roots 添加目录后 `scan --force`。目录内可随时加入文献；同日要求立即入库需强制刷新。脚本不修改原文和 Zotero。

`status` 只查 SQLite，不扫描文件树。`scan` 每天最多一次目录枚举，同日跳过；剩余解析用 `process`，避免为处理队列重复枚举目录。自动调用每轮最多一批；批量模式只有用户要求时持续执行。检索前如有 pending 且与问题有关，可在预算内处理。

指纹为路径、大小、纳秒修改时间，变化后计算 SHA256；副本共享内容索引和卡片。若外部程序修改内容却保留大小与时间，快速扫描无法发现；怀疑时检查文件哈希并重建对应记录，不能声称内容级实时监控。每日目录枚举仍为 O(文件数)，首次大库哈希可能较慢；20 秒是解析软预算，不包括目录枚举/哈希，不是硬性总时限。

状态：pending、indexed、partial（超过页数上限）、needs_ocr（几乎无文本）、error。indexed 仅表示文本抽取完成，不等于完整阅读或图表完整。稀疏页记在 error 字段作为警告，不改变已抽取文本。partial 可用已抽取部分；补足时提高配置上限后 `process --retry`。error/needs_ocr 不每次无限重试，修复解析器或完成 OCR 后再 retry。

`search` 是按页大小写不敏感的字面关键词 AND 查询，无语义排序；用短关键词/中英文同义词分轮查，不能因未命中断言不存在。limit 限制返回页数，不是论文数；对 sha 去重后筛选论文。只检索 active 来源；已移除文献需明确说明后再查看保留卡片。超过显示上限的队列可直接对 SQLite 分页查询，不把整库输出到上下文。

`page` 默认最多 6,000 字符，长页用 offset 分段。模型实际阅读后才写卡片，见 evidence.md。缓存保存原文片段和研究信息，应继承研究目录的访问保护，不随意上传或同步。避免两个写入进程同时扫描同一库。

## Zotero（按当前环境可用能力接入）

先发现可用 Zotero 连接器/工具，检查能否读取指定集合、条目、标签、笔记、附件与版本。不要假定存在某个工具名或可访问全文。默认只读，不修改 Zotero 条目、标签或附件。

1. 有连接器：只读用户指定 library/collections。保存 libraryID、itemKey、版本/修改时间、附件身份和与本地 sha 的映射到项目 `zotero-state.json`。优先服务端增量能力，正确处理分页；不存在时分页比对版本，不能只读第一页却宣布已同步。每天首次调用检查，全部指定范围成功后写独立 last_success；失败保留旧状态和错误，不混同本地扫描成功日期。删除条目保留历史，标来源失效。
2. 用户指定 Zotero 附件/链接目录：可加入 pdf_roots，得到 PDF 增量索引，但必须说明这不等于集合/标签/笔记同步。不要猜测 Zotero 默认目录，也不要写正在使用的 zotero.sqlite。
3. 用户提供 Zotero 导出：读取实际格式建立条目映射，记录导出时间；未再次导出时不能声称已检查实时 Zotero。库大小不大时按修改版本去重，不把附件路径失效当作已读全文。
4. 没有连接器也没有可访问导出/附件：说明所缺能力，请用户选接入方式，同时继续本地库任务；不得承诺 Zotero 已自动更新。

连接器全文检索结果可直接作为证据，无需强制复制进本地库；需要缓存附件时仅在授权范围下载，并写项目缓存。Zotero API 密钥只用宿主凭据机制或已有环境变量，不写入配置、日志或对话。外部 connector 的访问/上传权限按实际工具和用户授权执行。

## 自动化边界

skill 只在被加载执行时检查日期，无法保证宿主其他无关聊天的“每日首次使用”也触发。未被加载时不运行。明确调用 `$assist-research-paper` 最可靠；自动发现由宿主决定。

固定时间无人值守检查需要用户指定来源与日程并明确要求后，另用宿主 automation 能力创建；保持状态不变时安静，仅在有意义变化、失败或需用户行动时通知。此 skill 的安装不创建调度器、不启动常驻进程。
