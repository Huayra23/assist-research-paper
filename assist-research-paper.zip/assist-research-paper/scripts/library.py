"""Local, incremental PDF cache. Sources are read-only; no network operations."""
import argparse
import hashlib
import json
import os
import sqlite3
import sys
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path


def emit(value):
    print(json.dumps(value, ensure_ascii=False, indent=2))


def stamp():
    return datetime.now(timezone.utc).isoformat()


def today(config):
    name = config.get('timezone', 'Asia/Shanghai')
    try:
        from zoneinfo import ZoneInfo
        tz = ZoneInfo(name)
    except Exception:
        if name != 'Asia/Shanghai':
            raise ValueError('Timezone unavailable: ' + name)
        tz = timezone(timedelta(hours=8))
    return datetime.now(tz).date().isoformat()


def connect(folder):
    db = sqlite3.connect(str(folder / 'library.sqlite3'), timeout=10)
    db.row_factory = sqlite3.Row
    db.executescript('''
    CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS files(path TEXT PRIMARY KEY, size INTEGER,
      mtime INTEGER, sha TEXT, active INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS docs(sha TEXT PRIMARY KEY, status TEXT,
      total_pages INTEGER, indexed_pages INTEGER, error TEXT, updated TEXT);
    CREATE TABLE IF NOT EXISTS pages(sha TEXT, page INTEGER, text TEXT,
      PRIMARY KEY(sha,page));
    CREATE TABLE IF NOT EXISTS cards(sha TEXT PRIMARY KEY, body TEXT, updated TEXT);
    ''')
    return db


def meta(db, key):
    row = db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
    return row[0] if row else None


def setmeta(db, key, value):
    db.execute('INSERT OR REPLACE INTO meta VALUES(?,?)', (key, value))
    db.commit()


def summary(db):
    rows = db.execute('''SELECT d.sha, d.status, d.total_pages, d.indexed_pages,
      d.error, MIN(f.path) AS path, c.sha IS NOT NULL AS has_card
      FROM docs d JOIN files f ON f.sha=d.sha AND f.active=1
      LEFT JOIN cards c ON c.sha=d.sha GROUP BY d.sha ORDER BY path''').fetchall()
    counts = {}
    pending = []
    for r in rows:
        counts[r['status']] = counts.get(r['status'], 0) + 1
        if not r['has_card'] or r['status'] not in ('indexed',):
            pending.append(dict(r))
    return {'last_local_scan': meta(db, 'last_local_scan'),
            'active_documents': len(rows), 'counts': counts,
            'needs_attention': pending[:20], 'needs_attention_total': len(pending)}


def extract(path, maximum):
    try:
        import pymupdf as fitz
    except ImportError:
        try:
            import fitz
        except ImportError:
            fitz = None
    if fitz is not None:
        with fitz.open(str(path)) as doc:
            if doc.needs_pass:
                raise ValueError('Encrypted PDF requires password')
            total = len(doc)
            pages = [doc[i].get_text() for i in range(min(total, maximum))]
    else:
        try:
            from pypdf import PdfReader
        except ImportError:
            raise RuntimeError('Use Python with PyMuPDF or pypdf installed')
        doc = PdfReader(str(path))
        if doc.is_encrypted:
            raise ValueError('Encrypted PDF requires password')
        total = len(doc.pages)
        pages = [(doc.pages[i].extract_text() or '')
                 for i in range(min(total, maximum))]
    return total, pages


def scan(db, config, args):
    date = today(config)
    if meta(db, 'last_local_scan') == date and not args.force:
        return {'scan': 'already_checked_today', **summary(db)}
    roots = config.get('pdf_roots', [])
    if not roots:
        return {'scan': 'not_configured', 'message': 'Set pdf_roots or use a Zotero connector'}
    errors, seen = [], {}
    # Enumerate every configured root before changing any availability flags.
    for entry in roots:
        root = Path(entry)
        if not root.is_absolute() or not root.is_dir():
            errors.append({'root': str(root), 'error': 'Missing or non-absolute directory'})
            continue
        def walk_error(err):
            errors.append({'root': str(root), 'error': str(err)})
        for parent, dirs, names in os.walk(str(root), onerror=walk_error, followlinks=False):
            dirs[:] = [d for d in dirs if not Path(parent, d).is_symlink()]
            for name in names:
                p = Path(parent, name)
                if p.suffix.lower() != '.pdf' or p.is_symlink():
                    continue
                try:
                    stat = p.stat()
                    seen[str(p.resolve())] = (stat.st_size, stat.st_mtime_ns)
                except OSError as err:
                    errors.append({'path': str(p), 'error': str(err)})
    if errors:
        return {'scan': 'failed', 'errors': errors, **summary(db)}
    changed = 0
    for path, (size, modified) in seen.items():
        old = db.execute('SELECT * FROM files WHERE path=?', (path,)).fetchone()
        if old and old['size'] == size and old['mtime'] == modified:
            db.execute('UPDATE files SET active=1 WHERE path=?', (path,))
            continue
        try:
            h = hashlib.sha256()
            with open(path, 'rb') as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    h.update(chunk)
            stat = Path(path).stat()
            if (stat.st_size, stat.st_mtime_ns) != (size, modified):
                raise OSError('File changed while hashing; retry later')
            sha = h.hexdigest()
            db.execute('INSERT OR REPLACE INTO files VALUES(?,?,?,?,1)',
                       (path, size, modified, sha))
            db.execute('INSERT OR IGNORE INTO docs VALUES(?,?,?,?,?,?)',
                       (sha, 'pending', 0, 0, None, stamp()))
            changed += 1
        except OSError as err:
            errors.append({'path': path, 'error': str(err)})
    if not errors:
        for r in db.execute('SELECT path FROM files WHERE active=1').fetchall():
            if r['path'] not in seen:
                db.execute('UPDATE files SET active=0 WHERE path=?', (r['path'],))
    db.commit()
    # Scan completion does not imply parsing or reading completion.
    if not errors:
        setmeta(db, 'last_local_scan', date)
    processing = process(db, config, args)
    return {'scan': 'failed' if errors else 'completed', 'changed_paths': changed,
            'errors': errors, 'processing': processing, **summary(db)}


def process(db, config, args):
    limits = config.get('processing', {})
    maximum = args.max_files if args.max_files is not None else limits.get('max_files', 3)
    seconds = limits.get('seconds', 20)
    max_pages = limits.get('max_pages_per_pdf', 300)
    if maximum < 0 or seconds <= 0 or max_pages < 1:
        raise ValueError('Invalid processing budget')
    statuses = ('pending', 'error', 'partial', 'needs_ocr') if args.retry else ('pending',)
    placeholders = ','.join('?' for _ in statuses)
    rows = db.execute('''SELECT d.sha, MIN(f.path) AS path FROM docs d
      JOIN files f ON f.sha=d.sha AND f.active=1 WHERE d.status IN ('''
      + placeholders + ') GROUP BY d.sha ORDER BY path LIMIT ?',
      (*statuses, maximum)).fetchall()
    start = time.monotonic()
    results = []
    for row in rows:
        if time.monotonic() - start >= seconds:
            break
        sha, path = row['sha'], row['path']
        try:
            before = Path(path).stat()
            known = db.execute('SELECT size,mtime FROM files WHERE path=?', (path,)).fetchone()
            if (before.st_size, before.st_mtime_ns) != tuple(known):
                raise ValueError('Source changed; run scan --force')
            total, pages = extract(path, max_pages)
            after = Path(path).stat()
            if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise ValueError('Source changed during extraction; run scan --force')
            status = 'indexed' if len(pages) == total else 'partial'
            if not pages or sum(len(t.strip()) for t in pages) < 40:
                status = 'needs_ocr'
            sparse = [i + 1 for i, t in enumerate(pages) if len(t.strip()) < 40]
            db.execute('DELETE FROM pages WHERE sha=?', (sha,))
            db.executemany('INSERT INTO pages VALUES(?,?,?)',
                           [(sha, i + 1, t) for i, t in enumerate(pages)])
            warning = 'Sparse pages (may require visual check): ' + str(sparse[:30]) if sparse else None
            db.execute('UPDATE docs SET status=?,total_pages=?,indexed_pages=?,error=?,updated=? WHERE sha=?',
                       (status, total, len(pages), warning, stamp(), sha))
            db.commit()
            results.append({'sha': sha, 'status': status})
        except Exception as err:
            db.rollback()
            db.execute('UPDATE docs SET status=?,error=?,updated=? WHERE sha=?',
                       ('error', str(err), stamp(), sha))
            db.commit()
            results.append({'sha': sha, 'status': 'error', 'error': str(err)})
    return results


def search(db, args):
    terms = args.query.split()
    if not terms:
        raise ValueError('Provide short search terms; spaces mean AND on the same page')
    condition = ' AND '.join('instr(lower(p.text),lower(?))>0' for _ in terms)
    rows = db.execute('''SELECT p.sha,p.page,p.text,
      (SELECT MIN(path) FROM files WHERE sha=p.sha AND active=1) AS path
      FROM pages p WHERE EXISTS(SELECT 1 FROM files f WHERE f.sha=p.sha AND f.active=1)
      AND ''' + condition + ' LIMIT ?', (*terms, args.limit)).fetchall()
    hits = []
    for r in rows:
        body = r['text']
        at = body.lower().find(terms[0].lower())
        begin = max(0, at - 150)
        hits.append({'sha': r['sha'], 'path': r['path'], 'pdf_page': r['page'],
                     'snippet': body[begin:begin + args.chars]})
    return {'search': 'literal_keywords_AND_per_page', 'hits': hits,
            'note': 'No hit is not proof of absence. Try synonyms or separate terms.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True, help='Absolute JSON config path')
    commands = parser.add_subparsers(dest='command', required=True)
    init = commands.add_parser('init')
    init.add_argument('--root', action='append', default=[])
    commands.add_parser('status')
    for name in ('scan', 'process'):
        p = commands.add_parser(name)
        p.add_argument('--force', action='store_true')
        p.add_argument('--retry', action='store_true')
        p.add_argument('--max-files', type=int)
    p = commands.add_parser('search')
    p.add_argument('--query', required=True)
    p.add_argument('--limit', type=int, default=5)
    p.add_argument('--chars', type=int, default=1000)
    p = commands.add_parser('page')
    p.add_argument('--sha', required=True)
    p.add_argument('--number', type=int, required=True)
    p.add_argument('--offset', type=int, default=0)
    p.add_argument('--chars', type=int, default=6000)
    p = commands.add_parser('card')
    p.add_argument('--sha', required=True)
    p.add_argument('--input', help='JSON file; omit to read the stored card')
    args = parser.parse_args()
    path = Path(args.config)
    if not path.is_absolute():
        raise ValueError('--config must be absolute')
    if args.command == 'init':
        if path.exists():
            raise ValueError('Config exists; edit it without overwriting the library')
        roots = []
        for raw in args.root:
            root = Path(raw)
            if not root.is_absolute() or not root.is_dir():
                raise ValueError('Root must be an existing absolute directory: ' + raw)
            roots.append(str(root.resolve()))
        path.parent.mkdir(parents=True, exist_ok=True)
        config = {'timezone': 'Asia/Shanghai', 'pdf_roots': roots,
                  'processing': {'max_files': 3, 'seconds': 20, 'max_pages_per_pdf': 300},
                  'zotero': {'mode': 'unconfigured', 'collections': [], 'last_success': None}}
        with path.open('x', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        return emit({'created': str(path), 'sources_configured': bool(roots)})
    config = json.loads(path.read_text(encoding='utf-8-sig'))
    with connect(path.parent) as db:
        if args.command == 'status':
            result = summary(db)
        elif args.command == 'scan':
            result = scan(db, config, args)
        elif args.command == 'process':
            result = {'processing': process(db, config, args), **summary(db)}
        elif args.command == 'search':
            args.limit = max(1, min(args.limit, 20))
            args.chars = max(100, min(args.chars, 3000))
            result = search(db, args)
        elif args.command == 'page':
            r = db.execute('SELECT text FROM pages WHERE sha=? AND page=?',
                           (args.sha, args.number)).fetchone()
            if not r:
                raise ValueError('Page not indexed')
            offset = max(0, args.offset)
            count = max(100, min(args.chars, 15000))
            result = {'sha': args.sha, 'pdf_page': args.number, 'offset': offset,
                      'total_chars': len(r[0]), 'text': r[0][offset:offset + count],
                      'truncated': offset + count < len(r[0])}
        else:
            if args.input:
                card = json.loads(Path(args.input).read_text(encoding='utf-8-sig'))
                doc = db.execute('SELECT indexed_pages,total_pages,status FROM docs WHERE sha=?', (args.sha,)).fetchone()
                active = db.execute('SELECT 1 FROM files WHERE sha=? AND active=1', (args.sha,)).fetchone()
                pages = card.get('pages_read', [])
                if not doc or not active or not pages or any(type(n) is not int or n < 1 or n > doc[0] for n in pages):
                    raise ValueError('Card must reference an active version and indexed pages actually read')
                if card.get('coverage') not in ('initial', 'targeted', 'full'):
                    raise ValueError('coverage must be initial, targeted, or full')
                if card['coverage'] == 'full' and (doc['status'] != 'indexed' or
                        set(pages) != set(range(1, doc['total_pages'] + 1))):
                    raise ValueError('Full coverage requires every PDF page to be indexed and read; visual checks remain the agent responsibility')
                db.execute('INSERT OR REPLACE INTO cards VALUES(?,?,?)',
                           (args.sha, json.dumps(card, ensure_ascii=False), stamp()))
                db.commit()
            r = db.execute('SELECT body,updated FROM cards WHERE sha=?', (args.sha,)).fetchone()
            result = {'sha': args.sha, 'card': json.loads(r[0]) if r else None,
                      'updated': r[1] if r else None}
        emit(result)


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    try:
        main()
    except Exception as error:
        emit({'error': str(error)})
        sys.exit(1)
